<?php
/**
 * Plugin Name: HarborCache – Object Cache with Redis
 * Description: Fast Redis object caching for WordPress with clear insights, analytics and safe cache controls.
 * Version: 1.2.5
 * Text Domain: harborcache-object-cache-with-redis
 * Domain Path: /languages
 * Network: true
 * Requires PHP: 7.4
 * Requires at least: 6.6
 * Author: Shahid Irfan
 * Author URI: https://profiles.wordpress.org/shahidirfan100/
 * Primary Branch: main
 * License: GPL-3.0-only
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 *
 * @package HarborCache/Core
 */

defined( 'ABSPATH' ) || exit;
// A second object cache manager cannot safely share the legacy engine constants.
if ( ( defined( 'WP_REDIS_FILE' ) && WP_REDIS_FILE !== __FILE__ ) || ( defined( 'WP_REDIS_PLUGIN_PATH' ) && realpath( WP_REDIS_PLUGIN_PATH ) !== realpath( __DIR__ ) ) || ( defined( 'HARBORCACHE_PLUGIN_PATH' ) && realpath( HARBORCACHE_PLUGIN_PATH ) !== realpath( __DIR__ ) ) ) {
 add_action( 'admin_notices', static function () {
  $screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
  if ( ! $screen || ! in_array( $screen->id, array( 'plugins', 'plugins-network' ), true ) ) { return; }
  if ( ! current_user_can( 'activate_plugins' ) && ! current_user_can( 'manage_network_plugins' ) ) { return; }
  echo '<div class="notice notice-error"><p>' . esc_html__( 'Deactivate the other Redis object cache plugin before activating HarborCache.', 'harborcache-object-cache-with-redis' ) . '</p></div>';
 } );
 return;
}
define( 'HARBORCACHE_FILE', __FILE__ );
if ( ! defined( 'HARBORCACHE_PLUGIN_PATH' ) ) {
    define( 'HARBORCACHE_PLUGIN_PATH', untrailingslashit( plugin_dir_path( HARBORCACHE_FILE ) ) );
}
require_once HARBORCACHE_PLUGIN_PATH . '/includes/ch-config.php';
try { \HarborCache\Config::apply(); \HarborCache\Config::load(); }
catch ( \Throwable $harborcache_error ) { error_log( 'HarborCache configuration is invalid. Review HARBORCACHE_CONFIG and wp-content/harborcache-config.php.' ); return; } // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
require_once __DIR__ . '/includes/class-console.php';
\HarborCache\Console::boot();

define( 'HARBORCACHE_BASENAME', plugin_basename( HARBORCACHE_FILE ) );
define( 'HARBORCACHE_PLUGIN_DIR', plugin_dir_url( HARBORCACHE_FILE ) );

$harborcache_meta = get_file_data( HARBORCACHE_FILE, [ 'Version' => 'Version' ] );

define( 'HARBORCACHE_VERSION', $harborcache_meta['Version'] );

require_once HARBORCACHE_PLUGIN_PATH . '/includes/class-autoloader.php';

$harborcache_autoloader = new HarborCache\Core\Autoloader();
$harborcache_autoloader->register();
$harborcache_autoloader->add_namespace( 'HarborCache\Core', HARBORCACHE_PLUGIN_PATH . '/includes' );

HarborCache\Core\Plugin::instance();

if ( ! function_exists( 'redis_object_cache' ) ) {
    /**
     * Returns the plugin instance.
     *
     * @return HarborCache\Core\Plugin
     */
    function redis_object_cache() {
        return HarborCache\Core\Plugin::instance();
    }
}
