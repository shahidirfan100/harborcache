<?php
/** Remove only files and schedules owned by HarborCache. Redis entries expire. */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;
require_once __DIR__ . '/includes/ch-paths.php';
require_once ABSPATH . 'wp-admin/includes/file.php';
if ( WP_Filesystem() ) {
 $harborcache_fs = $GLOBALS['wp_filesystem'];
 $harborcache_dropin = \HarborCache\Paths::content( 'object-cache.php' );
 if ( ! is_link( $harborcache_dropin ) && $harborcache_fs->is_readable( $harborcache_dropin ) ) {
  $harborcache_contents = $harborcache_fs->get_contents( $harborcache_dropin );
  if ( false !== strpos( $harborcache_contents, 'HarborCache Drop-In' ) && false !== strpos( $harborcache_contents, 'HarborCache_Advanced_Cache' ) ) {
   $harborcache_fs->delete( $harborcache_dropin );
   wp_opcache_invalidate( $harborcache_dropin, true );
  }
 }
 $harborcache_config = \HarborCache\Paths::content( 'harborcache-config.php' );
 if ( ! is_link( $harborcache_config ) && $harborcache_fs->is_readable( $harborcache_config ) ) {
  $harborcache_config_text = $harborcache_fs->get_contents( $harborcache_config );
  if ( is_string( $harborcache_config_text ) && false !== strpos( $harborcache_config_text, 'HarborCache configuration' ) && false !== strpos( $harborcache_config_text, "defined( 'ABSPATH' )" ) ) {
   $harborcache_fs->delete( $harborcache_config );
  }
 }
}
wp_clear_scheduled_hook( 'harborcache_metrics_discard' );
wp_clear_scheduled_hook( 'rediscache_discard_metrics' ); // Remove the event name used by earlier HarborCache builds.
delete_option( 'harborcache_metrics_cron_migrated' );

wp_clear_scheduled_hook( 'harborcache_cleanup' );

wp_clear_scheduled_hook( 'harborcache_queries' );

foreach ( array( '_harborcache_connection_probe', '_harborcache_draft', '_harborcache_notice', '_harborcache_probe', '_harborcache_selftest' ) as $harborcache_meta ) {
	delete_metadata( 'user', 0, $harborcache_meta, '', true );
}
